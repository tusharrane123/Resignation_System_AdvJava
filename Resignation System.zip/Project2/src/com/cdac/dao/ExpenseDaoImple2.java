package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Expense2;

@Repository
public class ExpenseDaoImple2 implements ExpenseDao2 {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

/*
	@Override
	public void insertExpense(Expense expense) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(expense);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}
*/

	@Override
	public void deleteExpense(int empId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Expense2(empId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
	}

	@Override
	public Expense2 selectExpense(int empId) {
		Expense2 expense = hibernateTemplate.execute(new HibernateCallback<Expense2>() {

			@Override
			public Expense2 doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Expense2 ex = (Expense2)session.get(Expense2.class, empId);
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}
			
		});
		return expense;
	}

	@Override
	public void updateExpense(Expense2 expense) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Expense2 ex = (Expense2)session.get(Expense2.class, expense.getEmpId());
//				ex.setEmpName(expense.getEmpName());
//				ex.setEmpDept(expense.getEmpDept());
//				ex.setEmpProfile(expense.getEmpProfile());
//				ex.setEmpSal(expense.getEmpSal());
//				ex.setEmpLoc(expense.getEmpLoc());
//				ex.setJoinDate(expense.getJoinDate());
//				ex.setAppDate(expense.getAppDate());
//				ex.setEmpReason(expense.getEmpReason());
				ex.setStatus(expense.getStatus());
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}
/*
	@Override
	public Expense2 selectAllExpense(int userId) {
		Expense2 expense = hibernateTemplate.execute(new HibernateCallback<Expense2>() {

			@Override
			public Expense2 doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Expense2 ex = (Expense2)session.get(Expense2.class, userId);
				tr.commit();
				session.flush();
				session.close();
				return ex; 
			}
			
		});
		return expense;
	}
*/
	
	@Override
	public List<Expense2> selectAll() {
		List<Expense2> expList = hibernateTemplate.execute(new HibernateCallback<List<Expense2>>() {

			@Override
			public List<Expense2> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Expense2");
				List<Expense2> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return expList;
	}

}
