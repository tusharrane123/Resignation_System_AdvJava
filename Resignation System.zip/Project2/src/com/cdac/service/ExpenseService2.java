package com.cdac.service;

import java.util.List;

import com.cdac.dto.Expense2;

public interface ExpenseService2 {
//	void addExpense(Expense expense);
	void removeExpense(int empId);
	Expense2 findExpense(int empId);
	void modifyExpense(Expense2 expense);
//	Expense2 selectAllExpense(int userId);
	List<Expense2> selectAll();
}
