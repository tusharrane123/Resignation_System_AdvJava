package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employeeform")
public class Expense {
		@Id
		@GeneratedValue
		@Column(name = "emp_Id")
		private int empId;
		
		@Column(name = "emp_name")
		private String empName;
		
		@Column(name = "emp_dept")
		private String empDept;
		
		@Column(name = "emp_profile")
		private String empProfile;
		
		@Column(name = "emp_salary")
		private float empSal;
		
		@Column(name = "emp_location")
		private String empLoc;
		
		@Column(name = "join_date")
		private String joinDate;
		
		@Column(name = "res_reason")
		private String empReason;
		
		@Column(name = "app_date")
		private String appDate;
		
		@Column(name = "form_status")
		private String status;
		
		private int userId;
		
		public Expense() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public Expense(int empId) {
			super();
			this.empId = empId;
		}

		public int getEmpId() {
			return empId;
		}

		public void setEmpId(int empId) {
			this.empId = empId;
		}

		public String getEmpName() {
			return empName;
		}

		public void setEmpName(String empName) {
			this.empName = empName;
		}

		public String getEmpDept() {
			return empDept;
		}

		public void setEmpDept(String empDept) {
			this.empDept = empDept;
		}

		public String getEmpProfile() {
			return empProfile;
		}

		public void setEmpProfile(String empProfile) {
			this.empProfile = empProfile;
		}

		public float getEmpSal() {
			return empSal;
		}

		public void setEmpSal(float empSal) {
			this.empSal = empSal;
		}

		public String getEmpLoc() {
			return empLoc;
		}

		public void setEmpLoc(String empLoc) {
			this.empLoc = empLoc;
		}

		public String getJoinDate() {
			return joinDate;
		}

		public void setJoinDate(String joinDate) {
			this.joinDate = joinDate;
		}

		public String getEmpReason() {
			return empReason;
		}

		public void setEmpReason(String empReason) {
			this.empReason = empReason;
		}

		public String getAppDate() {
			return appDate;
		}

		public void setAppDate(String appDate) {
			this.appDate = appDate;
		}
		
		//Employee Form Status Accepted or Rejected
		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public int getUserId() {
			return userId;
		}

		public void setUserId(int userId) {
			this.userId = userId;
		}

}
	
