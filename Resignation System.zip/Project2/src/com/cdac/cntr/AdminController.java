package com.cdac.cntr;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Admin;
import com.cdac.service.AdminService;
import com.cdac.valid.AdminValidator;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService userService;
	
	@Autowired
	private AdminValidator adminValidator;
	
	//registration
	@RequestMapping(value = "/prep_admin_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("user", new Admin());
		return "admin_reg_form";
	}
	
	@RequestMapping(value = "/adminreg.htm",method = RequestMethod.POST)
	public String register(Admin user,ModelMap map) {
		userService.addUser(user);
		return "index";
	}
	
	//login
	@RequestMapping(value = "/prep_admin_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("user", new Admin());
		return "admin_login_form";
	}
	
	@RequestMapping(value = "/adminlogin.htm",method = RequestMethod.POST)
	public String login(Admin user,BindingResult result,ModelMap map,HttpSession session) {
		
		adminValidator.validate(user, result);
		if(result.hasErrors())
		{
			return "admin_login_form";
		}
		
		boolean b = userService.findUser(user);
		if(b) {
			session.setAttribute("user", user); 
			return "admin_home";
		}else {
			map.put("user", new Admin());
			return "admin_login_form";
		}
	}
	
	
}
