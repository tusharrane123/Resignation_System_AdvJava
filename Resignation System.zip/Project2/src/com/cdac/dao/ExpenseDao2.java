package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Expense2;

public interface ExpenseDao2 {
//	void insertExpense(Expense expense);
	void deleteExpense(int empId);
	Expense2 selectExpense(int empId);
	void updateExpense(Expense2 expense);
//	Expense2 selectAllExpense(int userId);
	List<Expense2> selectAll();
}
