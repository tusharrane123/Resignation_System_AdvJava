package com.cdac.dao;

import com.cdac.dto.Admin;

public interface AdminDao {
	void insertUser(Admin user);
	boolean checkUser(Admin user);
}
