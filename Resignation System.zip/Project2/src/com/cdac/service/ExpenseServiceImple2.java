package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.ExpenseDao2;
import com.cdac.dto.Expense2;

@Service
public class ExpenseServiceImple2 implements ExpenseService2 {
	
	@Autowired
	private ExpenseDao2 expenseDao;
/*
	@Override
	public void addExpense(Expense expense) {
		expenseDao.insertExpense(expense);
	}
*/
	@Override
	public void removeExpense(int empId) {
		expenseDao.deleteExpense(empId);
	}

	@Override
	public Expense2 findExpense(int empId) {
		return expenseDao.selectExpense(empId);
	}

	@Override
	public void modifyExpense(Expense2 expense) {
		expenseDao.updateExpense(expense);
	}
/*	
	@Override
	public Expense2 selectAllExpense(int userId) {
		return expenseDao.selectAllExpense(userId);
	}
*/	
	@Override
	public List<Expense2> selectAll() {
		return expenseDao.selectAll();
	}

}
