package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Expense;

public interface ExpenseDao {
	void insertExpense(Expense expense);
//	void deleteExpense(int empId);
//	Expense selectExpenxe(int empId);
//	void updateExpense(Expense expense);
	List<Expense> selectAll(int userId);
}
